package common;

public class Common {
	public static final String WEB_URL = "WEB-INF/view";
	public static final String ERR_URL = "WEB-INF/view/common/errorPage.jsp";



}
